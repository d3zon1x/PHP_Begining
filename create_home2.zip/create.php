<?php
    global $pdo;
    if ($_SERVER["REQUEST_METHOD"]=="POST"){
        $Name=$_POST["Name"];
        $Describtion=$_POST["Describtion"];
        $Photo=$_POST["Photo"];
        echo "$Name $Photo $Describtion\n";

        include("config/connection_db.php");
        $sql = "INSERT INTO tbl_product (Name, Photo, Describtion) VALUES (?, ?, ?)";
        $stmt = $pdo->prepare($sql);

        // Execute the query with the data
        $stmt->execute([$Name, $Photo, $Describtion]);
        header("Location: /");
        exit;
    }
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Create</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<?php include("_header.php")?>
    <div class="content-wrapper mt-5">
        <div class="container">
            <h1 class="text-center">Add product</h1>
            <form class="col-md-8 offset-md-2" method="post">
                <div class="mb-3">
                    <label for="Name" class="form-label">Name</label>
                    <input type="text" class="form-control" name="Name" id="Name">
                </div>
                <div class="mb-3">
                    <label for="Describtion" class="form-label">Describtion</label>
                    <textarea type="text" class="form-control" name="Describtion" id="Describtion"></textarea>
                </div>
                <div class="mb-3">
                    <label for="Photo" class="form-label">Photo</label>
                    <input type="file" class="form-control" name="Photo" id="Photo" onchange="displayPhoto()">
                </div>
                <img id="previewImage" src="#" alt="Preview" style="display: none; max-width: 100%;">
                <button class="btn btn-info" type="submit">Submit</button>
            </form>
        </div>
    </div>
    <script src="js/bootstrap.bundle.min.js"></script>
<script>
    function displayPhoto() {
        var input = document.getElementById('Photo');
        var preview = document.getElementById('previewImage');

        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                preview.src = e.target.result;
                preview.style.display = 'block';
            };

            reader.readAsDataURL(input.files[0]);
        }
    }
</script>
</body>
</html>